package com.tienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
